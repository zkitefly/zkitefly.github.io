# 梯子的介绍及教程

![](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com/zkitefly&count_bg=%23008080&title_bg=%23008080&icon=&icon_color=%23008080&title=zkitefly&edge_flat=false)

## 免责声明

以下内容的平台和作者与本文作者没有任何关系，仅推荐和介绍

**以下仅用于学习内容，请勿用于违法用途！！！**

## 梯子基础知识扫盲
> 
> [https://github.com/xuefanqiang/home/blob/master/pages/fundamentals.md](https://github.com/xuefanqiang/home/blob/master/pages/fundamentals.md)

## 「梯子」服务商

以下是目前（2023/02/10）我在用还不错的梯子服务商：

### 推荐：[DaBai](http://dd.ma/Dz4Hrtpw) · [备用链接](https://dabai.in/) 

> 每月60GB流量免费体验，体验无需支付任何费用
> 
> 可每天签到获取流量，价格较便宜，稳定性良好
> 
> 能发起工单，有客服提问

[91Merry](https://going.91merry-1.top/auth/register?code=KQDe) · [备用链接](https://thesixshadow.com/)

> 可每天签到获取流量，价格较便宜，稳定性良好

[一元机场](http://dd.ma/R4GyPGQZ) · [备用链接](https://xn--4gq62f52gdss.com/#/register?code=6rQoMBSy)

> 价格很便宜，较为稳定，延迟中等，性价比高

### 其他：

[Get A Free Node](https://getafreenode.com/)

> 提供 V2Ray 节点，是免费的！
> 该站为永久返利，返利为20%，所以邀请到5位付费用户即可永久免费使用

[SSRDOG](http://dd.ma/246IUVmO)

[*原链*](https://dog.ssrdog.com/#/register?code=T2ChrHbu)

> 价格较中等，免费还算够用，很稳定，延迟较低，能发起工单，号称 绝不跑路 

**如果你有好用的机场，不妨在下面的评论中分享下？qwq**

<!--
https://hashyun.top/
-->

<script src="https://giscus.app/client.js"
        data-repo="zkitefly/zkitefly.github.io"
        data-repo-id="R_kgDOHnuxMQ"
        data-category-id="DIC_kwDOHnuxMc4CR1BS"
        data-mapping="pathname"
        data-strict="1"
        data-reactions-enabled="1"
        data-emit-metadata="1"
        data-input-position="top"
        data-theme="preferred_color_scheme"
        data-lang="zh-CN"
        crossorigin="anonymous"
        async>
</script>
